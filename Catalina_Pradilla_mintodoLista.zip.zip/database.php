<?php
$pdo = new PDO(
"mysql:host=localhost;dbname=tasks;chartset=utf8",
"root",
"root"
); 